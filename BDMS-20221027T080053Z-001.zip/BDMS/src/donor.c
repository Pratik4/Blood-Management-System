
#include <donor.h>

char id[6];
int validation(long int aadharno, int age){
	char lenaadhar[100];
	sprintf(lenaadhar, "%ld", aadharno);
	int length = strlen(lenaadhar);
	if((length == 12) && (age > 18)){
		printf("\n\t the validation of Aadhar no and age is successfull..\n");
		return 1;
	}
	else
		return 0;	
}


void giveDonorId(long int aadharno, char name[]){
	char aadhar[100];
	sprintf(aadhar, "%ld", aadharno);
	for(int i=0; i<6; i++){
		if(i<2)
			id[i] = name[i];
		else
			id[i] = aadhar[i-2];
	}	
}

void donor()
{	struct donor
	{
		long int aadharno;
		char name[30];
		int age;
		char address[30];
		char bloodgrp[4];
		char donorid[6];
	};
	struct donor b;
	struct reglist
	{
		long int regaadharno;
		char regname[30];
		char regdonorid[6];
	};
	struct reglist reg;
	char a;
	int unit = 1;
	FILE *fp, *regulardonor;
	fp=fopen("BDONOR.DAT","ab+");    //Opening a Binary File
	if(fp==NULL)
	{
		puts("Cannot Open File");
		exit(0);
	}
	fseek(fp,0,SEEK_END);  //Putting the Pointer at the end of the File
	int counter = 1;
	do
	{
	long int aadharno;
	printf("\n\t Enter Aadhar No :- ");
	scanf("%ld", &b.aadharno);
	aadharno = b.aadharno;
	printf("\n\t Enter Name :- ");
	scanf("%s", b.name);
	printf("\n\tEnter Your Age :- ");
	scanf("%d",&b.age);
	int flag = validation(b.aadharno, b.age);
	if(flag == 0){
		printf("\n\tenter the correct Aadhar No. or age should be 18.\n");
		menu();
	}
	giveDonorId(b.aadharno, b.name);
	for(int i=0; i<6; i++){
		b.donorid[i] = id[i];
	}
	
	printf("\n\t Enter address :- ");
	fflush(stdin);
	scanf("%s",b.address);
	printf("\n\t Enter Blood group :- ");
	scanf("%s",b.bloodgrp);
	rewind(fp);
	int broke = 0;
	regulardonor = fopen("Regulardonorlist.DAT", "ab+");
	while(fread(&b,sizeof(b),1,fp)){
		if(b.aadharno == aadharno){
			counter+=1;
			if(counter >=3){
				while(fread(&reg,sizeof(reg),1,regulardonor)){
					if(reg.regaadharno == aadharno){
						printf("\n\n\t!!!!  You are a regular donor.  !!!!");
						printf("\n\t\t You donate more than 3.");	
						fclose(regulardonor);
						broke = 1;
						break;
					}
				}
				if(broke == 1)
					break;			
				reg.regaadharno = b.aadharno;
				memcpy(reg.regname, b.name, sizeof(b.name));
				memcpy(reg.regdonorid, id, sizeof(id));
				fwrite(&reg,sizeof(reg),1,regulardonor);
				fclose(regulardonor);
				printf("\n\n\t!!!!  You are a regular donor.  !!!!");	
			}
		}
	}
	rewind(fp);
	while(fread(&b,sizeof(b),1,fp)){
		if(b.aadharno == aadharno){
			unit+=1;
		}
	}
	printf("\n\t\tYou gave %d unit of blood.", unit);
	scanf("%c", &a);
	fwrite(&b,sizeof(b),1,fp);
	printf("\n\tDo You want to add another data\n\n\tEnter (Y for Yes / N for No) : ");
	scanf("%c", &a);

	}while(a=='Y'||a=='y');
	fclose(fp);		 //Closing the File
}


void receiver()
{
	struct receiver
	{
		long int raadharno;
		char rname[30];
		char chid[6];
	};
	struct donor
	{
		long int aadharno;
		char name[30];
		int age;
		char address[30];
		char bloodgrp[4];
		char donorid[6];
	};
	struct donor b;
	struct receiver r;
	char bld[4], Cid[6];
	long int raadharno;
	FILE *fp,*rp;
	fp = fopen("BDONOR.DAT","rb");
	rp = fopen("Daily_transaction.DAT","rb");
	printf("\n\t Enter Aadhar No :- ");
	scanf("%ld", &raadharno);
	int flag = validation(raadharno, 19);
	if(flag == 0){
		printf("\n\tenter the correct Aadhar No.\n");
		menu();
	}
	flag = 0;
	while(fread(&r,sizeof(r),1,rp)){
		if(r.raadharno == raadharno){
			printf("\tAlready Exist. You can't register right now.\n");	
			flag = 1;
			break;
		}	
	}
	if(flag == 0){
		r.raadharno = raadharno;
		printf("\n\t Enter Name :- ");
		scanf("%s", r.rname);
		if(fp==NULL)
		{
			puts("Cannot Open File");
			menu();
		}
		fseek(fp, 0, SEEK_END);
		long Fsize = ftell(fp);
		if(Fsize == 0){
			printf("\n\t\t!!!  File is Empty. !!!");
			menu();
		}
		printf("\n\tEnter the Blood Group: ");
		scanf("%s",bld);
		rewind(fp);
		int itr = 0;
		while(fread(&b,sizeof(b),1,fp))
		{
			if(strcmp(b.bloodgrp,bld)==0) //Mathching the Bloodgroup required with the one's present in Database
			{
				itr = 1;
				printf("\n\tAadhar no. : %ld \n\tName: %s \n\tDonor Id: %s \n\tAge: %d \n\tAddress: %s \n\tBlood Group: %s \n\n",b.aadharno,b.name,b.donorid,b.age,b.address,b.bloodgrp);
				continue;
			}
		}
		if(itr == 0){
			printf("\n\t\t!!! No Record Found.\n");
			menu();
		}
		rewind(fp);
		printf("\tChoose a donor id : ");
		scanf("%s", Cid);
		while(fread(&b,sizeof(b),1,fp))
		{
			if(strcmp(b.donorid,Cid)==0) //Mathching the Bloodgroup required with the one's present in Database
			{
				rp=fopen("Daily_transaction.DAT","ab+");
				memcpy(r.chid,Cid,sizeof(Cid));
				fwrite(&r,sizeof(r),1,rp);
				fclose(rp);
			}
		}
		printf("\n\tYour choosing donor details is in the Daily_transaction.");
		printf("\n\n\n\t\t Back to Main Menu......!!!");
		menu();
		fclose(fp);
	}
	else{
		fclose(fp);
		fclose(rp);
		menu();
	}
}



void vDailytra(){
	struct receiver
	{
		long int raadharno;
		char rname[30];
		char chid[6];
	};
	struct receiver r;
	FILE *rp;
	rp = fopen("Daily_transaction.DAT", "rb");
	if(rp==NULL)
	{
		printf("!!! Cannot Open File.!!!");
		menu();
	}
	fseek(rp, 0, SEEK_END);
	long Fsize = ftell(rp);
	if(Fsize == 0){
		printf("\n\t\t!!!  File is Empty. !!!");
		menu();
	}
	rewind(rp);
	while(fread(&r,sizeof(r),1,rp)){
		printf("\n\tReceiver_Aadhar no. : %ld \n\tReceiver_Name: %s \n\tDonor_Id: %s \n\n",r.raadharno,r.rname,r.chid);
	}
	fclose(rp);
}

void vRegdonor(){
	struct reglist
	{
		long int regaadharno;
		char regname[30];
		char regdonorid[6];
	};
	struct reglist reg;
	FILE *regulardonor;
	regulardonor = fopen("Regulardonorlist.DAT", "ab+");
	if(regulardonor==NULL)
	{
		printf("!!! Cannot Open File.!!!");
		menu();
	}
	fseek(regulardonor, 0, SEEK_END);
	long Fsize = ftell(regulardonor);
	if(Fsize == 0){
		printf("\n\t\t!!!  File is Empty. !!!");
		menu();
	}
	rewind(regulardonor);
	while(fread(&reg,sizeof(reg),1,regulardonor)){
		printf("\n\tRegular_Donor_Aadhar no. : %ld \n\tRegular_Donor_Name: %s \n\tRegular_Donor_Id: %s \n\n",reg.regaadharno,reg.regname,reg.regdonorid);
	}
	fclose(regulardonor);
}

void dataDeleting(){
	struct donor
	{
		long int aadharno;
		char name[30];
		int age;
		char address[30];
		char bloodgrp[4];
		char donorid[6];
	};
	struct donor b;
	FILE *kp, *pp;
	long int aadid;
	int found = 0;
	kp = fopen("BDONOR.DAT", "rb");
	if(kp==NULL)
	{
		printf("!!! File is not exist ..!!!");
		exit(0);
	}
	fseek(kp, 0, SEEK_END);
	long Fsize = ftell(kp);
	if(Fsize == 0){
		printf("\n\t\t!!!  File is Empty. !!!");
		exit(0);
	}
	pp = fopen("Temp.DAT", "wb+");
	printf("\n\tEnter the Aadhar no. of donor to delete the details : ");
	scanf("%ld", &aadid);
	rewind(kp);
	while(fread(&b,sizeof(b),1,kp)){
		fscanf(kp, "%ld %s %d %s %s %s",&b.aadharno, b.name, &b.age, b.address, b.bloodgrp, b.donorid);
		if(b.aadharno != aadid)
			fwrite(&b,sizeof(b),1,pp);
		else{
			found = 1;
			printf("\n\t\tMatch founded. Data got deleted."); 
		}
	}
	if(!found)
		printf("\n\t\tNo match found.");
	fclose(kp);
	fclose(pp);
	remove("BDONOR.DAT");
	rename("Temp.DAT", "BDONOR.DAT"); 
}

void dataEditing(){
	struct donor
	{
		long int aadharno;
		char name[30];
		int age;
		char address[30];
		char bloodgrp[4];
		char donorid[6];
	};
	struct donor b;
	long int aadid;
	char ch;
	FILE *tp, *fp;
	fp = fopen("BDONOR.DAT", "rb+");

	tp = fopen("Temp.DAT", "ab+");
	if(fp==NULL)
	{
		printf("\n\t!!! File is not exist ..!!!");
		exit(0);
	}
	fseek(fp, 0, SEEK_END);
	long Fsize = ftell(fp);
	if(Fsize == 0){
		printf("\n\t\t!!!  File is Empty. !!!");
		exit(0);
	}
	printf("\n\t\tEnter the unique Aadhar no. : ");
	scanf("%ld", &aadid);
	rewind(fp);
	while(fread(&b,sizeof(b),1,fp)){
		fscanf(fp,"%ld %s %d %s %s %s",&b.aadharno, b.name, &b.age, b.address, b.bloodgrp, b.donorid);
		if(b.aadharno == aadid){
			printf("\n\t\t1.%ld 2.%s 3.%d 4.%s 5.%s 6.%s \n", b.aadharno, b.name, b.age, b.address, b.bloodgrp, b.donorid);
			scanf("%c", &ch);
			printf("\n\t\tDo you want to change the name ? (Y / N): ");
			scanf("%c", &ch);
			if(ch == 'Y' || ch == 'y'){
				printf("\n\t\tEnter the new name : ");
				scanf("%s", b.name);
				giveDonorId(b.aadharno, b.name);
				for(int i=0; i<6; i++){
					b.donorid[i] = id[i];
				}
			}
			scanf("%c", &ch);
			printf("\n\t\tDo you want to change the age ? (Y / N): ");
			scanf("%c", &ch);
			if(ch == 'Y' || ch == 'y'){
				printf("\n\t\tEnter the new age : ");
				scanf("%d", &b.age);
			}
			scanf("%c", &ch);
			printf("\n\t\tDo you want to change the address ? (Y / N): ");
			scanf("%c", &ch);
			if(ch == 'Y' || ch == 'y'){
				printf("\n\t\tEnter the new address : ");
				scanf("%s", b.address);
			}
			fseek(fp, -sizeof(b), SEEK_CUR);
			fwrite(&b,sizeof(b),1,tp);
		}
		else{
			fwrite(&b,sizeof(b),1,tp);
		}
	}
	fclose(fp);
	fclose(tp);
	remove("BDONOR.DAT");
	rename("Temp.DAT", "BDONOR.DAT"); 
	menu();
}


void DisplayingAllDonor(){
	struct donor
	{
		long int aadharno;
		char name[30];
		int age;
		char address[30];
		char bloodgrp[4];
		char donorid[6];
	};
	struct donor b;
	FILE *fp;
	fp = fopen("BDONOR.DAT", "rb");
	if(fp==NULL)
	{
		printf("!!! Cannot Open File.!!!\n");
		exit(0);
	}
	fseek(fp, 0, SEEK_END);
	long Fsize = ftell(fp);
	if(Fsize == 0){
		printf("\n\t\t!!!  File is Empty. !!!\n");
		exit(0);
	}
	rewind(fp);
	while(fread(&b,sizeof(b),1,fp)){
		printf("\n\tAadhar no. : %ld \n\tName: %s \n\tDonor Id: %s \n\tAge: %d \n\tAddress: %s \n\tBlood Group: %s \n\n",b.aadharno,b.name,b.donorid,b.age,b.address,b.bloodgrp);	
}
fclose(fp);
}

void Admin(){
	int adpass = 2580; 
	int en = 1;
	int apassword;
	int ch;
	printf("\n\tEnter the 4 digit password for Admin : ");
	scanf("%d", &apassword);
	while(1){
	if(en < 3){	
		if(adpass == apassword){
			
			printf("\n\tEnter your choice! what you want to do!..........");
			printf("\n\t1. Viewing Daily trasaction.\n");
			printf("\n\t2. viewing regular donor list.\n");
			printf("\n\t3. delete the donor details.\n");
			printf("\n\t4. edit the details.\n");
			printf("\n\t5. displaying all donor details.\n");
			printf("\n\tYour choice is : ");
			scanf("%d", &ch);
			switch(ch){
				case 1: vDailytra();
					menu();
					break;
				case 2: vRegdonor();
					menu();
					break;
				case 3: dataDeleting();
					menu();
					break;
				case 4: dataEditing();
					menu();
					break;
				case 5: DisplayingAllDonor();
					menu();
					break;
				default:printf("\n\tYou entered Wrong choice!.");
					Admin();
			}
		}
		else{
			printf("\n\tYou entering wrong password.");
			printf("\n\tPlease enter correct password! !!attempt left - %d !!", 3 - en); 
			en = en + 1;
			Admin();
		}
		
	}
	else{
		printf("\tNo more attempt left.");
		menu();
	}
}
}


void menu()
{
	char choice[10];
	printf("\n\n\t\t\t\tBLOOD DONOR DATABASE \n\n\n");
	printf("\t1 Add details of donor.\n\n");
	printf("\t2 Search by Blood Group and showing results.\n\n");
	printf("\t3 Admin Login.\n\n");
	printf("\tYour Choice: ");
	scanf("%s",choice);
	int choi = atoi(choice);
	switch(choi)
	{
		case 1: donor();
			menu();
			break;
		case 2: receiver();
			menu();
			break;
		case 3: Admin();
			menu();
			break;
		default: printf("\n\n\t\tYou have entered wrong choice.....!!!");
			 menu();	 
	}
	
	
}


#ifndef DONOR_DOT_H
#define DONOR_DOT_H


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>


/////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////

void donor();           //Store the data in file
void receiver();
void Admin();
void menu();
void vDailytra();
void dataDeleting();
void vRegdonor();
void dataEditing();
void DisplayingAllDonor();
int validation(long int aadharno, int age);
void giveDonorId(long int aadharno, char name[]);

#endif
